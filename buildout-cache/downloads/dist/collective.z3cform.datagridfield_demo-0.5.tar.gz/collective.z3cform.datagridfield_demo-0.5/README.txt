Introduction
============

This package provides the demo views for collective.z3cform.datagridfield. See that 
package for more information.

Installation
------------

Add collective.z3cforms.datagridfield_demo to your buildout eggs.::

    eggs=\
        ...
        collective.z3cforms.datagridfield
        collective.z3cforms.datagridfield_demo

Examples of configurations are in the demo folder.
Once you install this package, the demo views will be visible on your site. ::

    * http://localhost:8080/Plone/@@demo-collective.z3cform.datagrid

References
----------
 
    * http://pypi.python.org/pypi/collective.z3cform.datagridfield


