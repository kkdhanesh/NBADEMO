=================
 z3c.saconfig
=================

Minimal SQLAlchemy ORM session configuration for Zope. See src/z3c/saconfig/README.rst.
