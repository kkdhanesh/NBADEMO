z3c.saconfig credits
====================

* Martijn Faassen (creator)

* Hermann Himmelbauer (inspired the engine factory code)

* Brian Sutherland (various contributions)

* Laurence Rowe, Martin Aspeli, Michael Bayer (useful design discussions)

  
